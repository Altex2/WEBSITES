<?php 

//Stripe Credentials Configuration
define("STRIPE_SECRET_API_KEY", "key");
define("STRIPE_PUBLISHABLE_KEY", "key");

//Sample Product Details
define('CURRENCY', 'EUR');
define('AMOUNT', '10');
define('DESCRIPTION', 'Laptop');

// Database Credentials Configuration 
define('DB_HOST', 'localhost');
define('DB_NAME', 'stripe_payment');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
?>